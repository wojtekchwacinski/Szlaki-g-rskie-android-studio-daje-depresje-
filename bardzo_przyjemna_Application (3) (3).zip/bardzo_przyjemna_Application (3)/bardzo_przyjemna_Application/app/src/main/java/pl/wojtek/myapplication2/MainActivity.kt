package pl.wojtek.myapplication2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabLayout
import android.view.MenuItem
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import androidx.appcompat.app.ActionBarDrawerToggle
import android.view.Window

class MainActivity: AppCompatActivity(),NavigationView.OnNavigationItemSelectedListener {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var viewPager: ViewPager
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        drawerLayout = findViewById(R.id.drawer_layout)
        val navView = findViewById<NavigationView>(R.id.nav_view)
        navView.setNavigationItemSelectedListener(this)


        viewPager = findViewById(R.id.viewPager) as ViewPager

        var tablayout: TabLayout = findViewById(R.id.tablayout) as TabLayout

        val fragmentAdapter = FragmentAdapter(supportFragmentManager)
        fragmentAdapter.addFragment(HomeFragment(), "Home")
        fragmentAdapter.addFragment(TatryFragment(), "Tatry")
        fragmentAdapter.addFragment(KarkonoszeFragment(), "Karkonosze")

        viewPager.adapter = fragmentAdapter
        tablayout.setupWithViewPager(viewPager)






    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_home -> {
                // Obsługa wyboru "Home"
                viewPager.currentItem = 0
                drawerLayout.closeDrawer(GravityCompat.START)
                return true
            }
            R.id.nav_tatry -> {
                // Obsługa wyboru "Gallery"
                viewPager.currentItem = 1
                drawerLayout.closeDrawer(GravityCompat.START)
                return true
            }
            R.id.nav_karpaty -> {
                // Obsługa wyboru "Settings"
                viewPager.currentItem = 2
                drawerLayout.closeDrawer(GravityCompat.START)
                return true
            }
        }
        return false
    }


    }
