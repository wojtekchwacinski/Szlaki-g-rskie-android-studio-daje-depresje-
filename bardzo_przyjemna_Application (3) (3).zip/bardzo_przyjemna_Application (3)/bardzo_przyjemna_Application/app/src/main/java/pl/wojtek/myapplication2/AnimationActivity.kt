package pl.wojtek.myapplication2

import android.animation.Animator
import android.animation.ObjectAnimator
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.animation.AnimatorSet


class AnimationActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_animation)

        val imageView = findViewById<View>(R.id.muala)
        val imageView2 = findViewById<View>(R.id.bear)

        val startX = -200f // Początkowa wartość X
        val endX = 200f // Końcowa wartość X (przesunięcie w prawo)
        val start2X = 0f
        val end2X = 500f
        val animator = ObjectAnimator.ofFloat(imageView, View.TRANSLATION_X, startX, endX, startX)
        val animator2 = ObjectAnimator.ofFloat(imageView2, View.TRANSLATION_X, 0f, -500f)



        animator2.duration = 2000
        animator.duration = 2000

        val animatorSet = AnimatorSet()

        animatorSet.playTogether(animator2, animator)
        animatorSet.addListener(object : Animator.AnimatorListener {
            override fun onAnimationStart(animation: Animator) {

            }

            override fun onAnimationEnd(animation: Animator) {
                // Po zakończeniu animacji, otwórz MainActivity
                val intent = Intent(this@AnimationActivity, MainActivity::class.java)
                startActivity(intent)
                finish()
            }

            override fun onAnimationCancel(animation: Animator) {}

            override fun onAnimationRepeat(animation: Animator) {

                }

        })

        animatorSet.start()
    }
}
