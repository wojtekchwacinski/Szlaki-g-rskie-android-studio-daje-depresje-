package pl.wojtek.myapplication2

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class KarkonoszeFragment : Fragment(), KarkonoszeAdapter.OnItemClickListener {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: KarkonoszeAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.rec_kark, container, false)

        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = GridLayoutManager(requireContext(), 2)

        // Lista szlaków
        val trails = listOf(
            "Szlak na Śnieżkę",
            "Szlak na Kopę",
            "Szlak na Śnieżne Kotły",
            "Szlak na Szrenice",
            "Ścieżka nad Redlami"
            // Dodaj więcej szlaków według potrzeb
        )

        // Adapter dla RecyclerView
        adapter = KarkonoszeAdapter(trails.map { it to R.drawable.gora_do_rec }, this)
        recyclerView.adapter = adapter

        return view
    }

    // Metoda wywoływana po kliknięciu na szlak
    override fun onItemClick(trailName: String, imageResource: Int) {

        val fragment = SzczegolyFragment.newInstance(trailName)
        requireActivity().supportFragmentManager.beginTransaction()
            .replace(R.id.fragmenContainer, fragment)
            .addToBackStack(null)
            .commit()
    }
}