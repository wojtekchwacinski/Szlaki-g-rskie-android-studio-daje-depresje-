package pl.wojtek.myapplication2
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import android.widget.Button
import android.widget.FrameLayout
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import android.graphics.Bitmap
import android.app.Activity
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.Manifest
import android.widget.ScrollView
import android.widget.Toolbar

class SzczegolyFragment : Fragment() {
    private var trasa: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            trasa = it.getString(ARG_TRASA)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment



        val view = inflater.inflate(R.layout.fragment_szczegoly, container, false)
        ///val fragmentContainerZegar: FrameLayout = view.findViewById(R.id.fragmentContainter)
        val scrol: ScrollView = view.findViewById(R.id.scrollView)
        val textView: TextView = view.findViewById(R.id.detailTextView)
        val hideButton: Button = view.findViewById(R.id.hideButton)


        val fab: FloatingActionButton= view.findViewById(R.id.fab)
        fab.setOnClickListener {
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.CAMERA), REQUEST_IMAGE_CAPTURE)
            } else {
                openCamera()
            }
        }


        textView.visibility = View.VISIBLE
        hideButton.visibility = View.VISIBLE
        //fragmentContainerZegar.visibility = View.VISIBLE
        textView.text = when (trasa) {
            "Szlak przez Dolinę Roztoki" ->"Szlak przez Dolinę Roztoki \n" +
                    "to malownicza trasa w Tatrach Zachodnich,\n" +
                    " prowadząca przez jedną z najpiękniejszych dolin\n" +
                    " w Tatrzańskim Parku Narodowym. Rozpoczyna się przy\n" +
                    " schronisku na Hali Gąsienicowej i prowadzi przez\n " +
                    "piękną dolinę, mijając potoki, wodospady i zielone łąki,\n" +
                    " aż do Polany Roztoki, gdzie znajduje się drugie\n" +
                    " schronisko. Trasa jest stosunkowo łatwa, ale oferuje\n" +
                    " niesamowite widoki na otaczające góry i przyrodę Tatr.\n\n\n\n\n\n\n\n\n\n"

            "Szlak Gęsia Szyja" ->

            "Szlak Gęsia Szyja\n" +
                    " to popularna trasa turystyczna w polskich Tatrach.\n" +
                    " Rozpoczyna się na polanie Chochołowskiej \n" +
                    "i prowadzi przez Dolinę Chochołowską\n" +
                    " w kierunku Czerwonych Wierchów. Jest\n" +
                    " to ścieżka o umiarkowanym stopniu trudności,\n" +
                    " co czyni ją dostępną dla szerokiego spektrum turystów.\n" +
                    " Szlak oferuje malownicze widoki na otaczające Tatry,\n" +
                    " a także na pobliskie łąki i lasy. Gęsia Szyja\n" +
                    " jest jednym z najbardziej lubianych szlaków\n" +
                    " w Tatrach ze względu na swoją urozmaiconą\n" +
                    " trasę i piękne krajobrazy.\n\n\n\n\n\n\n\n"

            "Szlak na Rusinową Polanę" ->
                "Szlak na Rusinową Polanę\n" +
                        " to popularna trasa turystyczna w polskich\n" +
                        " Tatrach Zachodnich. Rozpoczyna się z reguły\n" +
                        " w miejscowości Kuźnice koło Zakopanego.\n" +
                        " Prowadzi przez las i wzniesienia Tatr Zachodnich,\n" +
                        " oferując piękne widoki na okoliczne szczyty\n" +
                        " oraz otaczającą przyrodę. Trasa ta jest\n" +
                        " stosunkowo łatwa, co czyni ją dostępną dla\n" +
                        " turystów o różnym stopniu zaawansowania.\n" +
                        " Rusinowa Polana to przepiękne tereny\n" +
                        " o charakterze łąkowym, gdzie można odpocząć,\n" +
                        " zjeść posiłek, a nawet zorganizować nocleg\n" +
                        " w schronisku górskim. Szlak na Rusinową Polanę\n" +
                        " to doskonały wybór dla osób poszukujących\n" +
                        " spokojnego spaceru wśród górskich krajobrazów.\n\n\n\n\n"
            "Szlak na Rysy" ->
                "Szlak na Rysy\n" +
                        " to jedna z najbardziej wymagających tras\n" +
                        " turystycznych w polskich Tatrach. Rozpoczyna\n" +
                        " się z reguły w dolinie Morskie Oko, skąd prowadzi\n" +
                        " przez Czarny Staw pod Rysami do samego szczytu.\n" +
                        " Trasa jest długa i stroma, wymaga dobrej kondycji\n" +
                        " fizycznej i doświadczenia w górach. Początkowy\n" +
                        " odcinek to spacer wzdłuż malowniczego jeziora,\n" +
                        " następnie szlak prowadzi przez skaliste tereny,\n" +
                        " gdzie trzeba pokonać liczne podejścia\n" +
                        " i trudne fragmenty. Ostatni fragment szlaku\n " +
                        "to wyjście przez łańcuchy, co dodatkowo\n" +
                        " utrudnia przejście. Mimo trudności, trasa\n " +
                        "nagradza wspinaczy zapierającymi dech w piersiach\n " +
                        "widokami na Tatry i otaczającą przyrodę. Dochodząc\n" +
                        " na szczyt Rysów, można podziwiać przepaście,\n" +
                        " jeziora i szczyty górskie rozciągające się na\n" +
                        " horyzoncie. Ze względu na wymagający charakter trasy,\n" +
                        " warto być odpowiednio przygotowanym, mieć ze sobą\n" +
                        " odpowiedni sprzęt i zabrać ze sobą doświadczonego\n" +
                        " przewodnika górskiego.\n\n\n\n\n\n\n"
            "Szlak na Giewont" ->

                "Szlak na Giewont\n" +
                        " to jedna z najbardziej popularnych tras\n" +
                        " w polskich Tatrach. Rozpoczyna się zazwyczaj\n" +
                        " przy dolnej stacji kolejki linowej na\n" +
                        " Kasprowy Wierch lub z kuźnic. Trasa wiedzie\n" +
                        " przez piękną Dolinę Kondratową, gdzie można\n" +
                        " podziwiać malownicze krajobrazy tatrzańskie.\n" +
                        " Dalej prowadzi przez Polanę Kondratową i\n" +
                        " dalej w górę, aż do schroniska na Hali\n" +
                        " Kondratowej. Stamtąd szlak prowadzi stromym\n" +
                        " podejściem w górę, gdzie trzeba pokonać\n" +
                        " liczne kamienne schody i ścieżki. Ostatni\n" +
                        " fragment trasy to wszechobecne łańcuchy,\n" +
                        " które pomagają w pokonaniu stromych skałek\n" +
                        " i przekraczaniu niebezpiecznych odcinków.\n" +
                        " Dochodząc na szczyt Giewontu, można podziwiać\n" +
                        " panoramiczne widoki na całe Tatry oraz doliny\n" +
                        " pod nimi. Warto pamiętać, że szlak na Giewont\n" +
                        " jest wymagający fizycznie i technicznie,\n" +
                        " szczególnie w przypadku pokonywania łańcuchów,\n" +
                        " więc należy być odpowiednio przygotowanym i\n" +
                        " zachować ostrożność.\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n"
            "Szlak na Śnieżkę"->
                "Szlak na Śnieżkę\n" +
                        "\n" +
                        "Lokalizacja: Karkonosze, Polska\n" +
                        "Start: Zazwyczaj z Karpacza lub Schroniska Samotnia.\n" +
                        "Trasa: Prowadzi przez różnorodne tereny: lasy, łąki i skały.\n" +
                        "Atrakcje: Podczas wędrówki można podziwiać liczne punkty\n" +
                        " widokowe i panoramy Karkonoszy.\n" +
                        "Trudność: Średnio trudny, ale może być nieco wymagający\n" +
                        " od strony Szklarskiej Poręby.\n" +
                        "Długość: Około 7-10 km w jedną stronę.\n" +
                        "Przygotowanie: Zaleca się odpowiednie obuwie i odzież oraz\n prowiant na trasie.\n" +
                        "Na szczycie: Kopczyk kamienny z krzyżem oraz wieża widokowa.\n\n\n\n\n"

            "Szlak na Kopę" ->
                "Szlak na Kopę\n" +
                        "\n" +
                        "Lokalizacja: Karkonosze, Polska.\n" +
                        "Start: Zazwyczaj z Karpacza lub Schroniska Samotnia.\n" +
                        "Trasa: Prowadzi przez malownicze tereny Karkonoszy,\n" +
                        " wzdłuż potoków i lasów. Atrakcje: Szlak oferuje\n" +
                        " piękne widoki na okoliczne góry oraz naturalne\n" +
                        " atrakcje, takie jak wodospady i skalne formacje.\n" +
                        "Trudność: Średnio trudny, choć może być nieco\n" +
                        " wymagający w niektórych fragmentach.\n" +
                        "Długość: Zazwyczaj około 6-8 km w jedną stronę.\n" +
                        "Przygotowanie: Zalecane jest odpowiednie obuwie\n" +
                        " trekkingowe oraz prowiant na trasie.\n" +
                        "Na szczycie: Widokowy punkt widokowy lub\n" +
                        " skałki, z których można podziwiać panoramę Karkonoszy.\n\n\n\n\n"

            "Szlak na Śnieżne Kotły" ->
                "Szlak na Śnieżne Kotły\n" +
                        "\n" +
                        "Lokalizacja: Karkonosze, Polska.\n" +
                        "Start: Najczęściej z miejscowości Karpacz lub\n" +
                        " schroniska Samotnia. Trasa: Prowadzi przez\n" +
                        " malownicze tereny Karkonoszy, często zaczynając\n" +
                        " się od schroniska Samotnia lub przy wodospadzie\n" +
                        " Szklarki. Następnie prowadzi w kierunku\n" +
                        " Śnieżnych Kotłów, przebiegając przez potężne\n" +
                        " skały i rozległe łąki.\n" +
                        "Atrakcje: Szlak oferuje spektakularne widoki\n" +
                        " na okoliczne góry oraz niezwykłą przyrodę\n" +
                        " Karkonoszy, w tym na zasłyszane wodospady i strome urwiska.\n" +
                        "Trudność: Średnio trudny, ze względu na niektóre\n" +
                        " strome fragmenty oraz zmienne warunki terenowe.\n" +
                        "Długość: Zazwyczaj około 10-12 km w jedną stronę,\n" +
                        " w zależności od punktu startowego.\n" +
                        "Przygotowanie: Zalecane jest wygodne obuwie\n" +
                        " trekkingowe oraz odpowiednie ubranie, ze\n" +
                        " względu na zmienne warunki atmosferyczne w górach.\n" +
                        "Na miejscu: Po dotarciu do Śnieżnych Kotłów można\n" +
                        " podziwiać niezwykłe formacje skalne i jeziorka krasowe,\n" +
                        " które są jednymi z najbardziej charakterystycznych\n" +
                        " elementów krajobrazu Karkonoszy.\n\n\n\n\n\n"

            "Szlak na Szrenice" ->
                "Szlak na Szrenicę\n" +
                        "\n" +
                        "Lokalizacja: Karkonosze, Polska.\n" +
                        "Start: Najczęściej z miejscowości Szklarska\n" +
                        " Poręba lub z Karpacza. Trasa: Szlak prowadzi\n" +
                        " przez urozmaicone tereny Karkonoszy,\n" +
                        " zaczynając zazwyczaj w okolicach centrum\n" +
                        " Szklarskiej Poręby lub Karpacza. Następnie\n" +
                        " wiedzie przez lasy, polany i skaliste fragmenty,\n" +
                        " oferując widoki na charakterystyczne szczyty gór.\n" +
                        "Atrakcje: Podczas wędrówki można podziwiać piękne\n" +
                        " widoki na okoliczne szczyty, wodospady oraz górskie\n" +
                        " krajobrazy. Na szczyt Szrenicy często prowadzi\n" +
                        " kolej linowa, co stanowi dodatkową atrakcję.\n" +
                        "Trudność: Trasa jest zazwyczaj łatwa do\n" +
                        " średnio trudna, z niewielkimi różnicami\n" +
                        " wysokości i dobrze oznaczonymi szlakami.\n" +
                        "Długość: Średnio około 6-8 km w jedną stronę,\n" +
                        " w zależności od punktu startowego i wybranej trasy.\n" +
                        "Przygotowanie: Wygodne buty trekkingowe oraz odpowiednie\n" +
                        " ubranie dostosowane do warunków atmosferycznych w górach.\n" +
                        "Na miejscu: Po dotarciu na szczyt Szrenicy można podziwiać\n" +
                        " rozległe panoramy Karkonoszy oraz odpocząć w jednym z\n" +
                        " okolicznych schronisk górskich, smakując regionalne potrawy.\n\n\n\n\n"

            "Ścieżka nad Redlami" ->
                "Ściezka nad Redlami\n\n"+
                "Lokalizacja: Karkonosze, Polska.\n" +
                        "Start: Najczęściej ze Szklarskiej Poręby lub z Karpacza.\n" +
                        "Trasa: Szlak prowadzi wzdłuż potoku Redławska Struga,\n" +
                        " oferując przyjemny spacer przez lasy i łąki.\n" +
                        " Można podziwiać malownicze wodospady oraz\n" +
                        " okoliczne szczyty gór.\n" +
                        "Atrakcje: Ścieżka nad Redlami jest idealna dla\n" +
                        " osób poszukujących spokojnego spaceru wśród\n" +
                        " pięknych krajobrazów Karkonoszy. Można tu \n" +
                        "obserwować dziką przyrodę i odpocząć w cieniu drzew.\n" +
                        "Trudność: Trasa jest łatwa, odpowiednia dla rodzin\n" +
                        " z dziećmi i osób o różnym stopniu sprawności fizycznej.\n" +
                        "Długość: Zazwyczaj około 2-3 km w jedną stronę,\n" +
                        " co stanowi krótką wycieczkę na popołudniowy spacer.\n" +
                        "Przygotowanie: Wygodne buty turystyczne oraz lekkie\n" +
                        " ubranie dostosowane do warunków pogodowych.\n" +
                        "Na miejscu: Po przejściu ścieżki można odpocząć przy\n" +
                        " malowniczym potoku Redławska Struga lub zatrzymać\n" +
                        " się na pikniku na jednej z łąk. Dla miłośników\n" +
                        " fotografii oferuje się wiele pięknych kadrów natury.\n\n\n\n"


            else -> "Brak danych dla tej trasy."
        }
       // val fragmentZegar = FragmentZegar()
        //childFragmentManager.beginTransaction()
          //  .add(fragmentContainerZegar.id, fragmentZegar)
            //.commit()

        hideButton.setOnClickListener {
            textView.visibility = View.INVISIBLE
            textView.isClickable = false
            hideButton.visibility = View.INVISIBLE
            //fragmentContainerZegar.visibility = View.INVISIBLE
            fab.visibility = View.INVISIBLE
            scrol.visibility = View.INVISIBLE



        }

        return view
    }
    private fun openCamera() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (takePictureIntent.resolveActivity(requireActivity().packageManager) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {
            val takenImage = data?.extras?.get("data") as Bitmap
            // Tutaj możesz wyświetlić zdjęcie lub zrobić coś z nim
        }
    }
    companion object {
        private const val ARG_TRASA = "trasa"
        private const val REQUEST_IMAGE_CAPTURE = 1

        fun newInstance(trasa: String) =
            SzczegolyFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_TRASA, trasa)
                }
            }
    }
}