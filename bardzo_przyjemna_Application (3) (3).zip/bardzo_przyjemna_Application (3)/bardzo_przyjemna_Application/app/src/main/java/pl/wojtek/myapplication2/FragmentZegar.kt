package pl.wojtek.myapplication2

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import java.util.*
import android.widget.EditText


class FragmentZegar : Fragment(), View.OnClickListener {

    private var seconds:Int = 0
    private var seconds_that_passed:Long = 0
    private var running:Boolean = false
    private var wasRunning:Boolean = false
    private lateinit var clockTextView: TextView
    private lateinit var historyTextView: TextView
    private val historyList = mutableListOf<String>()

    private var selectedTrailName : String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if(savedInstanceState != null){
            seconds_that_passed = savedInstanceState.getLong("seconds_that_passed")
            seconds = savedInstanceState.getInt("seconds")
            running = savedInstanceState.getBoolean("running")
            wasRunning = savedInstanceState.getBoolean("wasRunning")
            selectedTrailName = savedInstanceState.getString("selectedTrailName","")
            val arrayListHistory = savedInstanceState.getStringArrayList("historyList")
            // Skonwertuj ArrayList<String> na MutableList<String>
            historyList.addAll(arrayListHistory.orEmpty())


        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val layout = inflater.inflate(R.layout.fragment_zegar, container, false)

        runStoper(layout)
        val starcik = layout.findViewById<View>(R.id.startButton).setOnClickListener(this)
        val stopik = layout.findViewById<View>(R.id.stopButton).setOnClickListener(this)
        val resecik = layout.findViewById<View>(R.id.resetButton).setOnClickListener(this)
        val texcik = layout.findViewById<View>(R.id.clockTextView)
        historyTextView = layout.findViewById(R.id.historyTextView)
        val szlakEditText = layout.findViewById<EditText>(R.id.szlakEditText)
        val addButton = layout.findViewById<Button>(R.id.addButton)

        addButton.setOnClickListener {
            val enteredSzlak = szlakEditText.text.toString()


            if (enteredSzlak.isNotEmpty()) {
                selectedTrailName = enteredSzlak
                szlakEditText.text.clear()
            }
        }

        updateHistoryTextView()



        return layout
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.startButton-> onClickStart()
            R.id.stopButton -> onClickStop()
            R.id.resetButton -> onClickReset()
        }
    }

    override fun onPause() {
        super.onPause()
        wasRunning = running
        running = false
    }

    override fun onResume() {
        super.onResume()
        if (wasRunning){
            running = true
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putLong("seconds_that_passed", seconds_that_passed)
        outState.putInt("seconds",seconds)
        outState.putBoolean("running",running)
        outState.putBoolean("wasRunning",wasRunning)
        outState.putString("selectedTrailName", selectedTrailName ?: "")
        val arrayListHistoryList = ArrayList<String>(historyList)
        outState.putStringArrayList("historyList", arrayListHistoryList)

    }

    private fun onClickStart(){
        running = true
        seconds_that_passed = System.currentTimeMillis() / 1000

    }

    private fun onClickStop(){
        running = false

    }

    private fun onClickReset(){
        running = false

        // Dodaj aktualny czas do historii, jeśli nazwa szlaku jest dostępna
        if (selectedTrailName.isNotEmpty()) {
            val hours = seconds / 3600
            val minutes = seconds % 3600 / 60
            val secs = seconds % 60
            val time = String.format("%d:%02d:%02d", hours, minutes, secs)
            val historyEntry = "Szlak: $selectedTrailName, Czas: $time"
            historyList.add(historyEntry)
            updateHistoryTextView()
        }
        seconds = 0

    }


    private fun updateHistoryTextView() {
        val historyText = historyList.joinToString(separator = "\n")
        historyTextView.text = historyText
    }
    private fun runStoper(view: View){
        val stoperText = view.findViewById<TextView>(R.id.clockTextView)
        val handler = android.os.Handler()
        handler.post(object : Runnable {
            override fun run() {
                val hours = seconds / 3600
                val minutes = seconds % 3600 / 60
                val secs = seconds % 60
                val time = String.format("%d:%02d:%02d", hours, minutes, secs)
                stoperText.text = time
                if (running) {
                    if ( ((System.currentTimeMillis() / 1000) - seconds_that_passed).toInt() == seconds) {
                        seconds++
                    } else {
                        seconds = (System.currentTimeMillis() / 1000 - seconds_that_passed).toInt()
                    }
                }
                handler.postDelayed(this, 1000)
            }
        })
    }

}