package pl.wojtek.myapplication2
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TatryAdapter(private val trails: List<Pair<String, Int>>, private val listener: OnItemClickListener) :
    RecyclerView.Adapter<TatryAdapter.TatryViewHolder>() {

    interface OnItemClickListener {
        fun onItemClick(trailName: String, imageResource: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TatryViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.fragment_tatry, parent, false)
        return TatryViewHolder(view)
    }

    override fun onBindViewHolder(holder: TatryViewHolder, position: Int) {
        val currentTrail = trails[position]
        holder.imageViewTrail.setImageResource(currentTrail.second)
        holder.textViewTrailName.text = currentTrail.first
        holder.itemView.setOnClickListener {
            listener.onItemClick(currentTrail.first, currentTrail.second)
        }
    }

    override fun getItemCount() = trails.size

    inner class TatryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageViewTrail: ImageView = itemView.findViewById(R.id.imageViewTrail)
        val textViewTrailName: TextView = itemView.findViewById(R.id.textViewTrailName)
    }
}