package pl.wojtek.myapplication2

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.GridLayoutManager

class TatryFragment : Fragment(), TatryAdapter.OnItemClickListener {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: TatryAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.rec, container, false)

        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = GridLayoutManager(requireContext(), 2)

        // Lista szlaków
        val trails = listOf(
            "Szlak przez Dolinę Roztoki",
            "Szlak Gęsia Szyja",
            "Szlak na Rusinową Polanę",
            "Szlak na Rysy",
            "Szlak na Giewont"
            // Dodaj więcej szlaków według potrzeb
        )

        // Adapter dla RecyclerView
        adapter = TatryAdapter(trails.map { it to R.drawable.gory_bez_tla }, this)
        recyclerView.adapter = adapter

        return view
    }

    // Metoda wywoływana po kliknięciu na szlak
    override fun onItemClick(trailName: String, imageResource: Int) {

        val fragment = SzczegolyFragment.newInstance(trailName)
        requireActivity().supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .addToBackStack(null)
            .commit()
    }
}